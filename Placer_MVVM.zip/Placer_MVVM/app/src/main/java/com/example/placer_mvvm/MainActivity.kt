package com.example.placer_mvvm

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.placer_mvvm.databinding.ActivityMainBinding
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val items: MutableList<FoodItems> = ArrayList()
        items.add(FoodItems(R.drawable.burger, "Burger", "P100"))
        items.add(FoodItems(R.drawable.pizza, "Pizza", "P100"))
        items.add(FoodItems(R.drawable.fries, "Fries", "P50"))


        binding.recyclerview.layoutManager = LinearLayoutManager(this)
        binding.recyclerview.adapter = FoodAdapter(items)
    }
}
