package com.example.placer_mvvm;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.placer_mvvm.databinding.ListItemBinding;

import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodViewHolder> {

    private final List<FoodItems> items;

    public FoodAdapter(List<FoodItems> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ListItemBinding binding = ListItemBinding.inflate(inflater, parent, false);
        return new FoodViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodItems currentItem = items.get(position);

        holder.binding.imageview.setImageResource(currentItem.getImage());
        holder.binding.foodName.setText(currentItem.getFoodName());
        holder.binding.foodPrice.setText(currentItem.getFoodPrice());
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }
}
