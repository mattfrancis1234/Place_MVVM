package com.example.placer_mvvm;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.placer_mvvm.databinding.ListItemBinding;

public class FoodViewHolder extends RecyclerView.ViewHolder {

    ListItemBinding binding;

    public FoodViewHolder(@NonNull ListItemBinding binding) {
        super(binding.getRoot());
        this.binding = binding;
    }
}
